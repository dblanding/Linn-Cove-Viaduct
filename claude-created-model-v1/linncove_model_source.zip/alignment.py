"""Linn Cove Viaduct geometry from FHWA plan sheets (BR2H7, Figg & Muller 1978).

Stations are in feet (Sta 276+78.50 -> 27678.50). All geometry applies to the
centerline at top of 2" bituminous overlay (sheet 19 note).

World frame: X = east, Y = north (NC State Plane grid bearings),
origin on centerline at C/L bearing Abutment 1 (Sta 276+78.50),
Z = elevation - 4300 ft (USGS 1929 datum). Units here: feet.
"""
import numpy as np

DEG = np.pi / 180


def dms(d, m=0, s=0):
    return (d + m / 60 + s / 3600) * DEG


# ---- Horizontal alignment: spiral-curve-spiral data at C/L bridge (sheet 19) ----
# (direction +1 = left/CCW, -1 = right), Rc, TS, Ls_in, Lc, Ls_out
CURVES = [
    dict(name="Curve 1", sign=+1, R=249.11, TS=27643.48, Ls_in=200.0, Lc=96.74, Ls_out=180.0),
    dict(name="Curve 2", sign=-1, R=249.11, TS=28126.35, Ls_in=180.0, Lc=147.97, Ls_out=180.0),
    dict(name="Curve 3", sign=+1, R=358.10, TS=28634.38, Ls_in=180.0, Lc=176.15, Ls_out=200.0),
]
for c in CURVES:
    c["SC"] = c["TS"] + c["Ls_in"]
    c["CS"] = c["SC"] + c["Lc"]
    c["ST"] = c["CS"] + c["Ls_out"]

# Back tangent ahead of Curve 1: N 58deg55'46" E (sheet 10: S58-55-46W looking back)
AZ0 = dms(58, 55, 46)          # azimuth, clockwise from north
STA0 = CURVES[0]["TS"]         # integration start
STA_ORIGIN = 27678.50          # C/L bearing Abutment 1
E_SUPER = 0.10                 # full superelevation, ft/ft


def curvature(s):
    """Signed curvature (1/ft, + = left) at station s."""
    for c in CURVES:
        k = c["sign"] / c["R"]
        if c["TS"] <= s < c["SC"]:
            return k * (s - c["TS"]) / c["Ls_in"]
        if c["SC"] <= s < c["CS"]:
            return k
        if c["CS"] <= s < c["ST"]:
            return k * (c["ST"] - s) / c["Ls_out"]
    return 0.0


def superelevation(s):
    """Cross slope (ft/ft), + = right edge high (left curves bank left)."""
    for c in CURVES:
        if c["TS"] <= s < c["ST"]:
            return E_SUPER * c["R"] * curvature(s)
    return 0.0


# ---- Vertical profile (sheet 19 vertical curve data) ----
VPC, VPT, L_VC = 27750.0, 28250.0, 500.0
EL_VPC, G1, G2 = 4400.95, -0.0244, -0.019


def grade_elev(s):
    if s <= VPC:
        return EL_VPC + G1 * (s - VPC)
    if s >= VPT:
        return EL_VPC + G1 * L_VC + (G2 - G1) * L_VC / 2 + G2 * (s - VPT)
    x = s - VPC
    return EL_VPC + G1 * x + (G2 - G1) / (2 * L_VC) * x * x


# ---- Integrate the plan geometry ----
_DS = 0.02
_S = np.arange(STA0, 29200.0 + _DS, _DS)
_k = np.array([curvature(s) for s in _S])
# heading as math angle (CCW from east)
_th0 = np.pi / 2 - AZ0
_th = _th0 + np.concatenate([[0], np.cumsum((_k[1:] + _k[:-1]) / 2 * _DS)])
_x = np.concatenate([[0], np.cumsum((np.cos(_th[1:]) + np.cos(_th[:-1])) / 2 * _DS)])
_y = np.concatenate([[0], np.cumsum((np.sin(_th[1:]) + np.sin(_th[:-1])) / 2 * _DS)])
_ox, _oy = np.interp(STA_ORIGIN, _S, _x), np.interp(STA_ORIGIN, _S, _y)
_x -= _ox
_y -= _oy


def plan(s):
    """(x, y, heading) on centerline at station s."""
    return (float(np.interp(s, _S, _x)), float(np.interp(s, _S, _y)),
            float(np.interp(s, _S, _th)))


def azimuth_str(th):
    az = (np.pi / 2 - th) / DEG % 360
    if az <= 90:
        q, a = ("N", "E"), az
    elif az <= 180:
        q, a = ("S", "E"), 180 - az
    elif az <= 270:
        q, a = ("S", "W"), az - 180
    else:
        q, a = ("N", "W"), 360 - az
    d = int(a); m = int((a - d) * 60); sec = ((a - d) * 60 - m) * 60
    return f"{q[0]}{d}°{m:02d}'{sec:04.1f}\"{q[1]}"


Z_DATUM = 4300.0


def section_frame(s):
    """Frame of the (vertical, radial) joint plane at station s.

    Returns origin O (C/L, top of overlay), t (horizontal tangent),
    u (section 'right' axis, rolled by superelevation), v (section 'up').
    """
    x, y, th = plan(s)
    t = np.array([np.cos(th), np.sin(th), 0.0])
    r = np.array([np.sin(th), -np.cos(th), 0.0])      # horizontal, to the right
    z = np.array([0, 0, 1.0])
    phi = np.arctan(superelevation(s))               # + raises right edge
    u = np.cos(phi) * r + np.sin(phi) * z
    v = -np.sin(phi) * r + np.cos(phi) * z
    O = np.array([x, y, grade_elev(s) - Z_DATUM])
    return O, t, u, v


if __name__ == "__main__":
    for c in CURVES:
        d = (c["Ls_in"] + c["Ls_out"]) / (2 * c["R"]) + c["Lc"] / c["R"]
        print(c["name"], "TS SC CS ST", c["TS"], c["SC"], round(c["CS"], 2), round(c["ST"], 2),
              "Delta =", round(d / DEG, 4), "deg")
    for s, label in [(28300, "Pier 4 (sheet 39: local tangent S12-14-43W)"),
                     (STA0, "TS curve 1"), (29190.53, "ST curve 3")]:
        print(label, azimuth_str(plan(s)[2]))
    L = 0
    pts = [plan(s)[:2] for s in (27678.5, 28921.5)]
    print("chord abut-abut", np.hypot(pts[1][0] - pts[0][0], pts[1][1] - pts[0][1]))
