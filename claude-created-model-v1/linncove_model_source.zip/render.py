import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from build import full_bridge, erection_scene, derrick_only, all_solids

LIGHT = np.array([0.4, -0.5, 0.8]); LIGHT /= np.linalg.norm(LIGHT)


def polys(solids):
    P, C = [], []
    for s in solids:
        for f in s.faces:
            pts = s.verts[f[0]]
            n = np.cross(pts[1] - pts[0], pts[2] - pts[0])
            nn = np.linalg.norm(n)
            if nn == 0:
                continue
            shade = 0.45 + 0.55 * abs(np.dot(n / nn, LIGHT))
            P.append(pts); C.append(np.clip(np.array(s.color) * shade, 0, 1))
    return P, C


def view(solids, fn, elev, azim, title, box=None, figsize=(16, 9), zoom=1.0):
    fig = plt.figure(figsize=figsize, dpi=110)
    ax = fig.add_subplot(111, projection="3d", computed_zorder=False)
    P, C = polys(solids)
    ax.add_collection3d(Poly3DCollection(P, facecolors=C, edgecolors=(0, 0, 0, 0.12), linewidths=0.15))
    V = np.vstack([s.verts for s in solids])
    lo, hi = (V.min(0), V.max(0)) if box is None else box
    c = (lo + hi) / 2; r = (hi - lo).max() / 2 / zoom
    ax.set_xlim(c[0] - r, c[0] + r); ax.set_ylim(c[1] - r, c[1] + r); ax.set_zlim(c[2] - r, c[2] + r)
    ax.set_box_aspect((1, 1, 1))
    ax.view_init(elev, azim); ax.set_axis_off()
    ax.set_title(title, fontsize=13)
    plt.tight_layout(); plt.savefig(fn); plt.close()


if __name__ == "__main__":
    bridge = all_solids(full_bridge())
    view(bridge, "out/preview_bridge_aerial.png", 28, -60, "Linn Cove Viaduct - as completed (from plan sheets)", zoom=1.9)
    view(bridge, "out/preview_bridge_below.png", 6, -150, "Looking along the S-curve from the north end", zoom=2.0)
    scene, info = erection_scene()
    ss = all_solids(scene)
    D = [s for s in ss if "Segment 65" in s.name][0]
    c = D.verts.mean(0)
    view(ss, "out/preview_erection_closeup.png", 14, -35, "Erection stage: S-20 stiffleg lowering segment 65 over Temporary Support 4-5",
         box=(c - [70, 70, 75], c + [70, 70, 45]))
    view(ss, "out/preview_erection_wide.png", 22, -70, "Erection stage (Piers 1-4 built, cantilever at Sta 283+94)", zoom=1.7)
    view(all_solids(derrick_only()), "out/preview_derrick.png", 15, -55, "American S-20 stiffleg derrick (representative)", zoom=1.3)
