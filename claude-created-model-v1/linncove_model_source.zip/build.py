"""Build the three STEP files."""
import numpy as np
from alignment import section_frame, plan, grade_elev, Z_DATUM, _S, _x, _y
from viaduct import (segment_layout, segment_solid, overlay_and_parapets, pier_solids, abutment_solids,
                     soffit_plane, DECK_START, DECK_END, OVERLAY, H_BOX)
from derrick import derrick, rigging, temp_support
from stepwriter import StepWriter, Node

OUT = "out"
AUTHOR = "Doug (model generated with Claude)"


def leaf(s):
    return Node(s.name, solid=s)


def deck_z(px, py):
    """Top of overlay elevation (model Z) at plan point, using the section plane at the nearest station."""
    i = np.argmin((_x - px) ** 2 + (_y - py) ** 2)
    O, t, u, v = section_frame(_S[i])
    # plane through O with normal v
    return O[2] - (v[0] * (px - O[0]) + v[1] * (py - O[1])) / v[2]


def full_bridge():
    segs = segment_layout()
    seg_nodes = [leaf(segment_solid(*sg)) for sg in segs]
    stations = [a for _, a, _, _ in segs] + [DECK_END]
    deck_extra = [leaf(s) for s in overlay_and_parapets(DECK_START, DECK_END, stations)]
    piers = []
    for i in range(7):
        cols, foot = pier_solids(i)
        piers.append(Node(f"Pier {i + 1}", [leaf(c) for c in cols] + [leaf(foot)]))
    abuts = [Node(f"Abutment {k + 1}", [leaf(s) for s in abutment_solids(k)]) for k in range(2)]
    return Node("Linn Cove Viaduct", [
        Node("Superstructure", [Node("Precast box segments 153-1", seg_nodes)] + deck_extra),
        Node("Substructure", piers + abuts)])


def all_solids(node):
    if node.solid is not None:
        return [node.solid]
    return [s for c in node.children for s in all_solids(c)]


def erection_scene(last=66, hanging=65, temp_s=28390.0, temp_ftg=4333.0):
    segs = segment_layout()
    by_num = {n: (n, a, b, p) for n, a, b, p in segs}
    built = [leaf(segment_solid(*by_num[n])) for n in range(153, last - 1, -1)]
    s_tip = by_num[last][2]
    piers = []
    for i in range(7):
        from viaduct import PIERS
        if PIERS[i] < s_tip:
            cols, foot = pier_solids(i)
            piers.append(Node(f"Pier {i + 1}", [leaf(c) for c in cols] + [leaf(foot)]))
    abut1 = Node("Abutment 1", [leaf(s) for s in abutment_solids(0)])
    temp = Node("Temporary support 4-5 (schematic)",
                [leaf(s) for s in temp_support(temp_s, plan, soffit_plane, temp_ftg, Z_DATUM)])

    # hanging segment: final position, raised 4 ft and held 6 in. ahead of the cantilever end
    n, a, b, p = by_num[hanging]
    seg = segment_solid(n, a, b, p, color=(0.86, 0.45, 0.30))
    O, t, u, v = section_frame(a)
    seg = seg.translated(t * 0.5 + np.array([0, 0, 4.0]), name=f"Segment {hanging} (being lowered)")
    cg = seg.verts.mean(axis=0)

    # derrick frame: mast two segments behind the segment being erected
    s_m = s_tip - 18.0
    xm, ym, thm = plan(s_m)
    zm = grade_elev(s_m) - Z_DATUM + 1.0            # base set level on 1 ft min. cribbing
    tm = np.array([np.cos(thm), np.sin(thm), 0]); lm = np.array([-np.sin(thm), np.cos(thm), 0])
    R = np.column_stack([tm, lm, [0, 0, 1.0]])
    Om = np.array([xm, ym, zm])
    to_local = lambda P: R.T @ (np.asarray(P) - Om)

    # lifting points on the hanging segment top slab, hook above its centroid
    Os, ts, us, vs = section_frame((a + b) / 2)
    top_c = Os + ts * 0.5 + np.array([0, 0, 4.0]) - vs * OVERLAY
    lift_w = [top_c + us * su * 6.0 + ts * st * 2.0 for su in (-1, 1) for st in (-1, 1)]
    hook_w = np.array([cg[0], cg[1], top_c[2] + 11.0])
    hook_l = to_local(hook_w)
    slew = np.degrees(np.arctan2(hook_l[1], hook_l[0]))
    reach = np.hypot(hook_l[0], hook_l[1]) - 2.0 - 0.9       # foot offset, point-sheave offset
    elev = np.degrees(np.arccos(reach / 70.0))

    # cribbing heights: from base underside (local z=0) down to the deck at mast foot and sill ends
    crib_pts = [np.array([0, 0, 0]), np.array([-30, 14, 0]), np.array([-30, -14, 0])]
    cribs = []
    for pl in crib_pts:
        pw = Om + R @ pl
        cribs.append((pl, pw[2] - deck_z(pw[0], pw[1]) - OVERLAY * 0))
    parts, tip_l, Rz = derrick(slew, elev, cribs=cribs)
    hook_l2 = np.array([hook_l[0], hook_l[1], hook_l[2]])
    rig = rigging(tip_l + Rz @ np.array([0.9, 0, 0]), hook_l2, [to_local(p) for p in lift_w])
    parts["Rigging"] = rig
    der_nodes = [Node(k, [leaf(s.transformed(R, Om)) for s in v]) for k, v in parts.items() if v]
    info = dict(slew=slew, boom_elev=elev, radius=np.hypot(hook_l[0], hook_l[1]),
                tip_height=(Om + R @ tip_l)[2] - deck_z(*(Om + R @ tip_l)[:2]), s_tip=s_tip, s_mast=s_m)
    scene = Node(f"Linn Cove Viaduct - erection of segment {hanging}", [
        Node(f"Erected segments 153-{last}", built),
        Node("Substructure (built)", piers + [abut1]),
        temp,
        Node("American S-20 stiffleg derrick", der_nodes),
        leaf(seg)])
    return scene, info


def derrick_only():
    parts, tip, Rz = derrick(0.0, 70.0)
    tipr = tip + np.array([0.9, 0, 0])
    hook = tipr - np.array([0, 0, 25.0])
    parts["Rigging"] = rigging(tipr, hook, [hook + np.array([sx * 4, sy * 4, -10]) for sx in (-1, 1) for sy in (-1, 1)])
    return Node("American S-20 stiffleg derrick (representative)",
                [Node(k, [leaf(s) for s in v]) for k, v in parts.items()])


if __name__ == "__main__":
    import os, json
    os.makedirs(OUT, exist_ok=True)
    results = {}
    for name, (root, desc) in {
        "Linn_Cove_Viaduct.step": (full_bridge(), "Linn Cove Viaduct, Blue Ridge Parkway, as completed"),
        "Stiffleg_Derrick_S20.step": (derrick_only(), "American S-20 stiffleg derrick, representative model"),
    }.items():
        for s in all_solids(root):
            s.check()
        n = StepWriter().write(root, f"{OUT}/{name}", desc, AUTHOR)
        results[name] = (len(all_solids(root)), n)
    scene, info = erection_scene()
    for s in all_solids(scene):
        s.check()
    n = StepWriter().write(scene, f"{OUT}/Linn_Cove_Erection_Stage.step",
                           "Linn Cove Viaduct during progressive placing, segment 65 being lowered", AUTHOR)
    results["Linn_Cove_Erection_Stage.step"] = (len(all_solids(scene)), n)
    print(json.dumps(results, indent=1))
    print({k: round(float(v), 2) for k, v in info.items()})
