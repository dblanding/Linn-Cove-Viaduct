"""Planar-faced (polyhedral) B-rep solids.

A Solid is a vertex array plus faces; each face is a list of loops
(outer loop first, then holes), each loop a list of vertex indices.
Outer loops run counter-clockwise seen from outside, holes clockwise.
Units: feet (converted to mm by the STEP writer).
"""
import numpy as np

PLANAR_TOL = 1e-6  # ft (~0.0003 mm): quads off-plane by more than this are split into triangles


class Solid:
    def __init__(self, name, verts, faces, color=(0.7, 0.7, 0.7)):
        self.name = name
        self.verts = np.asarray(verts, dtype=float)
        self.faces = faces
        self.color = color

    def transformed(self, R, t, name=None):
        v = self.verts @ np.asarray(R).T + np.asarray(t)
        return Solid(name or self.name, v, self.faces, self.color)

    def translated(self, d, name=None):
        return self.transformed(np.eye(3), d, name)

    def volume(self):
        vol = 0.0
        for face in self.faces:
            for loop in face:
                p = self.verts[loop]
                for i in range(1, len(p) - 1):
                    vol += np.dot(p[0], np.cross(p[i], p[i + 1]))
        return vol / 6.0

    def check(self):
        """Closed, consistently oriented, planar faces, positive volume."""
        used = {}
        for face in self.faces:
            for loop in face:
                for a, b in zip(loop, loop[1:] + loop[:1]):
                    if (a, b) in used:
                        raise ValueError(f"{self.name}: directed edge {a}->{b} used twice")
                    used[(a, b)] = True
        for (a, b) in used:
            if (b, a) not in used:
                raise ValueError(f"{self.name}: edge {a}->{b} has no partner (open shell)")
        for face in self.faces:
            n, d = face_plane(self.verts, face[0])
            for loop in face:
                dev = np.abs(self.verts[loop] @ n - d).max()
                if dev > 10 * PLANAR_TOL:
                    raise ValueError(f"{self.name}: non-planar face, deviation {dev:.2e} ft")
        if self.volume() <= 0:
            raise ValueError(f"{self.name}: non-positive volume")
        return True


def newell_normal(P):
    n = np.zeros(3)
    for i in range(len(P)):
        a, b = P[i], P[(i + 1) % len(P)]
        n += [(a[1] - b[1]) * (a[2] + b[2]), (a[2] - b[2]) * (a[0] + b[0]), (a[0] - b[0]) * (a[1] + b[1])]
    return n / np.linalg.norm(n)


def face_plane(V, loop):
    P = V[loop]
    n = newell_normal(P)
    return n, float(np.mean(P @ n))


def _quad_or_tris(V, q):
    n, d = face_plane(V, q)
    if np.abs(V[q] @ n - d).max() <= PLANAR_TOL:
        return [[q]]
    a, b, c, e = q
    return [[[a, b, c]], [[a, c, e]]]


def loft(name, sections, color=(0.7, 0.7, 0.7)):
    """Ruled solid through a list of sections.

    Each section is a list of 3D point arrays: [outer, hole1, hole2...],
    all sections having the same loop structure and point counts.
    """
    verts, idx = [], []
    for sec in sections:
        sidx = []
        for loop in sec:
            start = len(verts)
            verts.extend(np.asarray(loop, float))
            sidx.append(list(range(start, start + len(loop))))
        idx.append(sidx)
    V = np.array(verts)
    faces = [[list(l) for l in idx[0]]]                      # start cap
    faces.append([list(reversed(l)) for l in idx[-1]])        # end cap
    for A, B in zip(idx[:-1], idx[1:]):
        for la, lb in zip(A, B):
            m = len(la)
            for i in range(m):
                j = (i + 1) % m
                faces.extend(_quad_or_tris(V, [la[j], la[i], lb[i], lb[j]]))
    s = Solid(name, V, faces, color)
    if s.volume() < 0:
        s.faces = [[list(reversed(l)) for l in f] for f in s.faces]
    return s


def frame_points(profile, origin, ex, ey):
    """Map 2D (x, y) profile points to 3D: origin + x*ex + y*ey."""
    p = np.asarray(profile, float)
    return np.asarray(origin) + np.outer(p[:, 0], ex) + np.outer(p[:, 1], ey)


def ccw(poly):
    p = np.asarray(poly, float)
    a = 0.5 * np.sum(p[:, 0] * np.roll(p[:, 1], -1) - np.roll(p[:, 0], -1) * p[:, 1])
    return p if a > 0 else p[::-1]


def cw(poly):
    return ccw(poly)[::-1]


def circle(r, n=32, phase=0.0):
    a = phase + np.linspace(0, 2 * np.pi, n, endpoint=False)
    return np.c_[r * np.cos(a), r * np.sin(a)]


def rect(w, h, cx=0.0, cy=0.0):
    return np.array([[cx - w / 2, cy - h / 2], [cx + w / 2, cy - h / 2],
                     [cx + w / 2, cy + h / 2], [cx - w / 2, cy + h / 2]])


def _perp_frame(d):
    d = d / np.linalg.norm(d)
    ref = np.array([0, 0, 1.0]) if abs(d[2]) < 0.9 else np.array([1.0, 0, 0])
    ex = np.cross(ref, d); ex /= np.linalg.norm(ex)
    ey = np.cross(d, ex)
    return ex, ey


def member(name, p0, p1, profile, color, up=None):
    """Straight prismatic member from p0 to p1 with a 2D cross-section."""
    p0, p1 = np.asarray(p0, float), np.asarray(p1, float)
    d = p1 - p0
    if up is None:
        ex, ey = _perp_frame(d)
    else:
        dn = d / np.linalg.norm(d)
        ex = np.cross(up, dn); ex /= np.linalg.norm(ex)
        ey = np.cross(dn, ex)
    prof = ccw(profile)
    return loft(name, [[frame_points(prof, p0, ex, ey)], [frame_points(prof, p1, ex, ey)]], color)


def bar(name, p0, p1, size, color):
    return member(name, p0, p1, rect(size, size), color)


def rod(name, p0, p1, dia, color, n=8):
    return member(name, p0, p1, circle(dia / 2, n), color)


def box(name, center, dx, dy, dz, color, R=np.eye(3)):
    c = np.asarray(center, float)
    p0 = c - R[:, 2] * dz / 2
    p1 = c + R[:, 2] * dz / 2
    prof = ccw(rect(dx, dy))
    return loft(name, [[frame_points(prof, p0, R[:, 0], R[:, 1])],
                       [frame_points(prof, p1, R[:, 0], R[:, 1])]], color)


def vertical_prism(name, outer, holes, z0, z1_or_plane, origin, ex, ey, color):
    """Vertical prism of a plan profile (local ex/ey axes at origin).

    z1_or_plane: a top elevation, or (n, d) of a top plane n.x = d.
    """
    outer3 = frame_points(ccw(outer), origin, ex, ey)
    holes3 = [frame_points(cw(h), origin, ex, ey) for h in holes]

    def at_z(P, z):
        P = P.copy(); P[:, 2] = z; return P

    def on_plane(P, n, d):
        P = P.copy(); P[:, 2] = (d - P[:, 0] * n[0] - P[:, 1] * n[1]) / n[2]; return P

    bot = [at_z(outer3, z0)] + [at_z(h, z0) for h in holes3]
    if isinstance(z1_or_plane, tuple):
        n, d = z1_or_plane
        top = [on_plane(outer3, n, d)] + [on_plane(h, n, d) for h in holes3]
    else:
        top = [at_z(outer3, z1_or_plane)] + [at_z(h, z1_or_plane) for h in holes3]
    return loft(name, [bot, top], color)
