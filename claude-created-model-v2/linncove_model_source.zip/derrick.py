"""American S-20 stiffleg derrick (representative model) and temporary support.

Published facts (Muller & Barker, PCI Journal Sep-Oct 1985): American S-20
stiffleg, 70 ft boom, 125 kips at 25 ft radius, set on the end of the
completed cantilever about two segments behind the segment being erected,
moved forward on steel rollers. Member sizes and frame proportions below are
representative assumptions, not from drawings.

Local frame: origin at mast axis on the base, x forward, y left, z up (ft).
"""
import numpy as np
from polysolid import bar, rod, box, member, rect, circle, vertical_prism, loft, frame_points, ccw

YELLOW = (0.93, 0.70, 0.10)
DARK = (0.25, 0.25, 0.27)
ROPE = (0.10, 0.10, 0.10)
STEEL = (0.45, 0.50, 0.55)
TIMBER = (0.55, 0.40, 0.25)
CWT = (0.62, 0.62, 0.60)

MAST_H = 42.0          # mast height above base (assumed)
SILL_BACK, SILL_HALF = 30.0, 14.0
BOOM_L = 70.0
FOOT_OFF, FOOT_Z = 2.0, 3.0


def lattice(prefix, p0, p1, w0, w1, chord, lace, panel, color, wm=None):
    """Square lattice column/boom from p0 to p1, width w0 -> (wm at middle) -> w1."""
    p0, p1 = np.asarray(p0, float), np.asarray(p1, float)
    d = p1 - p0; L = np.linalg.norm(d); dn = d / L
    ref = np.array([0, 0, 1.0]) if abs(dn[2]) < 0.9 else np.array([1.0, 0, 0])
    ex = np.cross(ref, dn); ex /= np.linalg.norm(ex); ey = np.cross(dn, ex)
    wm = wm or (w0 + w1) / 2

    def width(f):
        return w0 + (wm - w0) * f / 0.5 if f <= 0.5 else wm + (w1 - wm) * (f - 0.5) / 0.5

    def corner(f, i):
        w = (width(f) - chord) / 2
        sx, sy = [(1, 1), (-1, 1), (-1, -1), (1, -1)][i]
        return p0 + d * f + ex * sx * w + ey * sy * w

    out = []
    nseg = max(2, int(round(L / panel)))
    fs = np.linspace(0, 1, nseg + 1)
    for i in range(4):  # chords as piecewise members (keeps the taper)
        for a, b in zip(fs[:-1], fs[1:]):
            out.append(bar(f"{prefix} chord {i + 1}", corner(a, i), corner(b, i), chord, color))
    for k, (a, b) in enumerate(zip(fs[:-1], fs[1:])):
        for i in range(4):
            j = (i + 1) % 4
            p, q = (corner(a, i), corner(b, j)) if k % 2 == 0 else (corner(a, j), corner(b, i))
            out.append(bar(f"{prefix} lacing", p, q, lace, color))
    return out


SILL_L = 28.0          # sill / stiffleg footprint length (assumed)


def derrick(slew_deg=0.0, boom_elev_deg=70.0, hook_drop=None, cribs=None,
            sill_dirs=(180.0, 270.0), hoist_at=(-13.0, 7.5)):
    """Return dict of sub-assembly name -> list of solids (local coordinates).

    sill_dirs: plan directions (deg, CCW from local +x = forward) of the two sills.
    The default puts one sill straight back along the deck and the other out to the
    right (downhill), so the 90 deg closed quadrant faces back-right, over open air.
    """
    parts = {"Base frame and stifflegs": [], "Mast": [], "Boom": [], "Hoist and counterweight": [], "Rigging": []}
    B = parts["Base frame and stifflegs"]
    zc = 0.75
    sill_ends = [np.array([SILL_L * np.cos(np.radians(a)), SILL_L * np.sin(np.radians(a)), zc]) for a in sill_dirs]
    for i, e in enumerate(sill_ends):
        B.append(member(f"Sill {i + 1}", [0, 0, zc], e, rect(1.25, 1.5), YELLOW, up=np.array([0, 0, 1.0])))
    B.append(box("Mast foot block", [0, 0, 0.9], 5, 5, 1.8, DARK))
    top = np.array([0, 0, MAST_H + 1.8])
    for i, e in enumerate(sill_ends):
        inward = -e[:2] / np.linalg.norm(e[:2]) * 1.5
        B.append(rod(f"Stiffleg {i + 1}", top, e + [inward[0], inward[1], 0.75], 1.6, YELLOW, n=12))
        B.append(box(f"Stiffleg shoe {i + 1}", e + [0, 0, 1.0], 3.5, 3.0, 0.5, DARK))
    B.append(member("Sill brace", sill_ends[0] * 0.45, sill_ends[1] * 0.45, rect(0.8, 0.8), YELLOW,
                    up=np.array([0, 0, 1.0])))

    # mast (rotates on foot and gudgeon pin; carries the boom)
    c, s = np.cos(np.radians(slew_deg)), np.sin(np.radians(slew_deg))
    Rz = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
    M = lattice("Mast", [0, 0, 1.8], [0, 0, MAST_H + 1.0], 3.5, 3.5, 0.5, 0.22, 3.5, YELLOW)
    M.append(box("Mast cap / gudgeon", [0, 0, MAST_H + 1.6], 4.5, 4.5, 1.2, DARK))
    M.append(box("Boom foot bracket", [FOOT_OFF - 0.5, 0, FOOT_Z], 2.5, 4.5, 2.0, DARK))
    parts["Mast"] = [m.transformed(Rz, [0, 0, 0]) for m in M]

    # boom in the slewed vertical plane
    a = np.radians(boom_elev_deg)
    foot = np.array([FOOT_OFF, 0, FOOT_Z])
    tip = foot + BOOM_L * np.array([np.cos(a), 0, np.sin(a)])
    Bm = lattice("Boom", foot, tip, 2.4, 2.0, 0.42, 0.2, 5.0, YELLOW, wm=4.0)
    Bm.append(box("Boom point sheave head", tip + [0.4, 0, 0.3], 2.6, 2.4, 1.6, DARK))
    for yy in (-0.55, 0.55):
        Bm.append(member("Point sheave", tip + [0.9, yy - 0.2, 0], tip + [0.9, yy + 0.2, 0], circle(1.1, 16), DARK))
    # topping lift (boom hoist) blocks and rope parts: mast top -> boom tip
    mt = np.array([0.4, 0, MAST_H + 2.4])
    Bm.append(box("Topping lift block (mast)", mt + [0.6, 0, 0], 1.4, 1.6, 1.6, DARK))
    Bm.append(box("Topping lift block (boom)", tip + [-0.6, 0, 1.2], 1.4, 1.6, 1.6, DARK))
    for yy in (-0.45, -0.15, 0.15, 0.45):
        Bm.append(rod("Topping lift rope", mt + [1.2, yy, 0], tip + [-1.2, yy, 1.2], 0.09, ROPE, n=6))
    parts["Boom"] = [m.transformed(Rz, [0, 0, 0]) for m in Bm]
    tip_w = Rz @ tip

    # hoist house and counterweights (fixed to the base)
    H = parts["Hoist and counterweight"]
    hx, hy = hoist_at
    H.append(box("Hoist engine house", [hx, hy, 3.5], 9, 7, 6, (0.80, 0.55, 0.10)))
    for xx in (hx + 2.5, hx + 0.2):
        H.append(member("Hoist drum", [xx, hy - 4.4, 4.2], [xx, hy + 4.4, 4.2], circle(1.0, 16), DARK))
    H.append(box("Hoist skid", [hx, hy, 0.25], 10, 8, 0.5, DARK))
    for i, e in enumerate(sill_ends):
        back = e[:2] / np.linalg.norm(e[:2]) * -2.5
        H.append(box(f"Counterweight {i + 1}", e + [back[0], back[1], 3.5], 4.5, 4.5, 4, CWT))

    # timber cribbing under the base (heights to the deck surface given by caller)
    if cribs:
        for i, (p, h) in enumerate(cribs):
            if h is not None and h > 0.05:
                H.append(box(f"Cribbing {i + 1}", [p[0], p[1], -h / 2], 4, 4, h, TIMBER))

    return parts, tip_w, Rz


def rigging(tip, hook, lift_pts):
    """Load line from boom point to hook block, slings to segment lifting points (world/local)."""
    R = []
    for yy in (-0.3, 0.3):
        for xx in (-0.3, 0.3):
            R.append(rod("Load line", tip + [xx, yy, -1.1], hook + [xx, yy, 1.8], 0.09, ROPE, n=6))
    R.append(box("Hook block", hook + [0, 0, 0.9], 1.6, 1.2, 2.4, YELLOW))
    R.append(rod("Hook", hook + [0, 0, -0.3], hook + [0, 0, -1.2], 0.45, DARK, n=8))
    for i, p in enumerate(lift_pts):
        R.append(rod(f"Sling {i + 1}", hook + [0, 0, -1.2], p, 0.12, ROPE, n=6))
    return R


def temp_support(s, plan, soffit_plane, z_footing_top, z_datum):
    """Temporary steel pipe support tower (sheet 113 schematic, Temp Support 2-3)."""
    x, y, th = plan(s)
    t = np.array([np.cos(th), np.sin(th), 0.0]); r = np.array([np.sin(th), -np.cos(th), 0.0])
    ctr = np.array([x, y, 0.0])
    zf = z_footing_top - z_datum
    n, d = soffit_plane(s)
    zsoff = lambda p: (d - n[0] * p[0] - n[1] * p[1]) / n[2]
    out = []
    pts = [ctr + r * o for o in (-7.333, 7.333)]
    z_cap_top = min(zsoff(ctr + r * o) for o in (-9, 9)) - 2.0
    z_cap_bot = z_cap_top - 2.5
    for i, p in enumerate(pts):
        out.append(vertical_prism(f"Temp footing {i + 1} (6x6x3)", rect(6, 6), [], zf - 3, zf, p, r, t, (0.6, 0.6, 0.58)))
        out.append(member(f"Steel pipe {i + 1}", [p[0], p[1], zf], [p[0], p[1], z_cap_bot], circle(1.0, 20), STEEL))
    cap_c = np.array([ctr[0], ctr[1], (z_cap_top + z_cap_bot) / 2])
    Rm = np.column_stack([r, t, [0, 0, 1]])
    out.append(box("Cap beam", cap_c, 20, 3.0, 2.5, STEEL, R=Rm))
    for i, o in enumerate((-6.0, 6.0)):
        p = ctr + r * o
        out.append(vertical_prism(f"Jack {i + 1}", circle(0.75, 16), [], z_cap_top, (n, d), p, r, t, DARK))
    # bracing between the pipes
    zs = np.linspace(zf + 2, z_cap_bot - 1, max(2, int((z_cap_bot - zf) / 12)) + 1)
    for k, (za, zb) in enumerate(zip(zs[:-1], zs[1:])):
        a0, a1 = pts[0] + [0, 0, za], pts[1] + [0, 0, za]
        b0, b1 = pts[0] + [0, 0, zb], pts[1] + [0, 0, zb]
        out.append(rod("Brace", a0 + r * 1.0, b1 - r * 1.0, 0.5, STEEL, n=8))
        out.append(rod("Brace", a1 - r * 1.0, b0 + r * 1.0, 0.5, STEEL, n=8))
        out.append(rod("Strut", b0 + r * 1.0, b1 - r * 1.0, 0.6, STEEL, n=8))
    return out
