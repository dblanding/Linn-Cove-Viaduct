"""Build the three STEP files."""
import numpy as np
from alignment import section_frame, plan, grade_elev, Z_DATUM, _S, _x, _y
from viaduct import (segment_layout, segment_solid, overlay_and_parapets, pier_solids, abutment_solids,
                     soffit_plane, DECK_START, DECK_END, OVERLAY, H_BOX)
from derrick import derrick, rigging, temp_support
from stepwriter import StepWriter, Node

OUT = "out"
AUTHOR = "Doug (model generated with Claude)"


def leaf(s):
    return Node(s.name, solid=s)


def deck_point(px, py):
    """(top-of-overlay model Z, signed lateral offset +right of stationing) at a plan point."""
    i = np.argmin((_x - px) ** 2 + (_y - py) ** 2)
    O, t, u, v = section_frame(_S[i])
    r = np.array([u[0], u[1], 0.0]); r /= np.linalg.norm(r)
    off = (px - O[0]) * r[0] + (py - O[1]) * r[1]
    z = O[2] - (v[0] * (px - O[0]) + v[1] * (py - O[1])) / v[2]
    return z, off


def full_bridge():
    segs = segment_layout()
    seg_nodes = [leaf(segment_solid(*sg)) for sg in segs]
    stations = [a for _, a, _, _ in segs] + [DECK_END]
    deck_extra = [leaf(s) for s in overlay_and_parapets(DECK_START, DECK_END, stations)]
    piers = []
    for i in range(7):
        cols, foot = pier_solids(i)
        piers.append(Node(f"Pier {i + 1}", [leaf(c) for c in cols] + [leaf(foot)]))
    abuts = [Node(f"Abutment {k + 1}", [leaf(s) for s in abutment_solids(k)]) for k in range(2)]
    return Node("Linn Cove Viaduct", [
        Node("Superstructure", [Node("Precast box segments 153-1", seg_nodes)] + deck_extra),
        Node("Substructure", piers + abuts)])


def all_solids(node):
    if node.solid is not None:
        return [node.solid]
    return [s for c in node.children for s in all_solids(c)]


WEB_OFFSET = 9.6          # web centreline at top-slab level, ft from C/L (sheet 56)


def erection_scene(last=64, hanging=65, temp_s=28390.0, temp_ftg=4333.0):
    """Progressive placing from Abutment 2 (south, low end, segment 1) toward Abutment 1."""
    from viaduct import PIERS
    segs = segment_layout()
    by_num = {n: (n, a, b, p) for n, a, b, p in segs}
    built = [leaf(segment_solid(*by_num[n])) for n in range(1, last + 1)]
    s_tip = by_num[last][1]                       # erection runs toward decreasing stations
    piers = []
    for i in range(7):
        if PIERS[i] > s_tip:
            cols, foot = pier_solids(i)
            piers.append(Node(f"Pier {i + 1}", [leaf(c) for c in cols] + [leaf(foot)]))
    abut2 = Node("Abutment 2", [leaf(s) for s in abutment_solids(1)])
    temp = Node("Temporary support 4-5 (schematic)",
                [leaf(s) for s in temp_support(temp_s, plan, soffit_plane, temp_ftg, Z_DATUM)])

    # hanging segment: final position, raised 4 ft and held 6 in. clear of the cantilever end
    n, a, b, p = by_num[hanging]
    seg = segment_solid(n, a, b, p, color=(0.86, 0.45, 0.30))
    O, t, u, v = section_frame(b)
    seg = seg.translated(-t * 0.5 + np.array([0, 0, 4.0]), name=f"Segment {hanging} (being lowered)")
    cg = seg.verts.mean(axis=0)

    # derrick: swing axis over the downhill (left-of-stationing) web of the next-to-last segment
    n63, a63, b63, _ = by_num[last - 1]
    s_m = (a63 + b63) / 2
    xm, ym, thm = plan(s_m)
    fwd = -np.array([np.cos(thm), np.sin(thm), 0])            # erection direction
    lft = np.array([-fwd[1], fwd[0], 0])                        # left of the erection direction (uphill)
    mast_xy = np.array([xm, ym, 0]) - lft * WEB_OFFSET          # downhill = right of erection direction
    R = np.column_stack([fwd, lft, [0, 0, 1.0]])

    sill_dirs, hoist_at = (180.0, 270.0), (-13.0, 7.5)
    supports = [np.array([0.0, 0, 0])] + \
        [28.0 * np.array([np.cos(np.radians(d)), np.sin(np.radians(d)), 0]) for d in sill_dirs] + \
        [np.array([hoist_at[0], hoist_at[1], 0])]
    deck = []
    for pl in supports:
        pw = mast_xy + R @ pl
        z, off = deck_point(pw[0], pw[1])
        deck.append(z if abs(off) <= 18.75 - 1.6 else None)    # inside the parapets?
    zm = max(z for z in deck if z is not None) + 1.0             # level base, 1 ft min cribbing
    Om = np.array([mast_xy[0], mast_xy[1], zm])
    to_local = lambda P: R.T @ (np.asarray(P) - Om)
    cribs = [(pl, None if z is None else zm - z) for pl, z in zip(supports, deck)]
    over_air = [i for i, z in enumerate(deck) if z is None]

    Os, ts, us, vs = section_frame((a + b) / 2)
    top_c = Os - ts * 0.5 + np.array([0, 0, 4.0]) - vs * OVERLAY
    lift_w = [top_c + us * su * 6.0 + ts * st * 2.0 for su in (-1, 1) for st in (-1, 1)]
    hook_w = np.array([cg[0], cg[1], top_c[2] + 11.0])
    hook_l = to_local(hook_w)
    slew = np.degrees(np.arctan2(hook_l[1], hook_l[0]))
    reach = np.hypot(hook_l[0], hook_l[1]) - 2.0 - 0.9
    elev = np.degrees(np.arccos(reach / 70.0))

    parts, tip_l, Rz = derrick(slew, elev, cribs=cribs, sill_dirs=sill_dirs, hoist_at=hoist_at)
    rig = rigging(tip_l + Rz @ np.array([0.9, 0, 0]), hook_l, [to_local(p) for p in lift_w])
    parts["Rigging"] = rig
    der_nodes = [Node(k, [leaf(s.transformed(R, Om)) for s in v]) for k, v in parts.items() if v]
    tipw = Om + R @ tip_l
    info = dict(slew_from_erection_dir=slew, boom_elev=elev, hook_radius=np.hypot(hook_l[0], hook_l[1]),
                tip_above_deck=tipw[2] - deck_point(*tipw[:2])[0], s_tip=s_tip, s_mast=s_m,
                supports_over_air=over_air, mast_offset_from_CL=deck_point(*Om[:2])[1])
    scene = Node(f"Linn Cove Viaduct - erection of segment {hanging}", [
        Node(f"Erected segments 1-{last}", built),
        Node("Substructure (built)", piers + [abut2]),
        temp,
        Node("American S-20 stiffleg derrick", der_nodes),
        leaf(seg)])
    return scene, info


def derrick_only():
    parts, tip, Rz = derrick(0.0, 70.0)
    tipr = tip + np.array([0.9, 0, 0])
    hook = tipr - np.array([0, 0, 25.0])
    parts["Rigging"] = rigging(tipr, hook, [hook + np.array([sx * 4, sy * 4, -10]) for sx in (-1, 1) for sy in (-1, 1)])
    return Node("American S-20 stiffleg derrick (representative)",
                [Node(k, [leaf(s) for s in v]) for k, v in parts.items()])


if __name__ == "__main__":
    import os, json
    os.makedirs(OUT, exist_ok=True)
    results = {}
    for name, (root, desc) in {
        "Linn_Cove_Viaduct.step": (full_bridge(), "Linn Cove Viaduct, Blue Ridge Parkway, as completed"),
        "Stiffleg_Derrick_S20.step": (derrick_only(), "American S-20 stiffleg derrick, representative model"),
    }.items():
        for s in all_solids(root):
            s.check()
        n = StepWriter().write(root, f"{OUT}/{name}", desc, AUTHOR)
        results[name] = (len(all_solids(root)), n)
    scene, info = erection_scene()
    for s in all_solids(scene):
        s.check()
    n = StepWriter().write(scene, f"{OUT}/Linn_Cove_Erection_Stage.step",
                           "Linn Cove Viaduct during progressive placing, segment 65 being lowered", AUTHOR)
    results["Linn_Cove_Erection_Stage.step"] = (len(all_solids(scene)), n)
    print(json.dumps(results, indent=1))
    print({k: (round(float(v), 2) if np.isscalar(v) else v) for k, v in info.items()})
