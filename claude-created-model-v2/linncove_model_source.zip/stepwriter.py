"""Minimal ISO 10303-21 (STEP AP214) writer for planar polyhedral solids.

Writes an assembly tree (nested products) whose leaves are
MANIFOLD_SOLID_BREPs built from ADVANCED_FACEs on PLANEs, with
per-part surface colors. Geometry is given in feet, written in mm.
"""
import datetime
import numpy as np

FT = 304.8  # mm per foot


def _f(x):
    s = repr(float(x))
    if "e" in s or "E" in s:
        m, e = s.lower().split("e")
        if "." not in m:
            m += "."
        return f"{m}E{int(e)}"
    return s if "." in s else s + "."


def _s(text):
    return "'" + str(text).replace("'", "''") + "'"


class Node:
    """Assembly node: either children (sub-assembly) or a solid (part)."""
    def __init__(self, name, children=None, solid=None):
        self.name, self.children, self.solid = name, children or [], solid


class StepWriter:
    def __init__(self):
        self.lines = []
        self.n = 0
        self._colors = {}

    def add(self, text):
        self.n += 1
        self.lines.append(f"#{self.n}={text};")
        return f"#{self.n}"

    # ---------- shared context ----------
    def _context(self):
        a = self.add
        self.app_ctx = a("APPLICATION_CONTEXT('core data for automotive mechanical design processes')")
        a(f"APPLICATION_PROTOCOL_DEFINITION('international standard','automotive_design',2000,{self.app_ctx})")
        self.prod_ctx = a(f"PRODUCT_CONTEXT('',{self.app_ctx},'mechanical')")
        self.pd_ctx = a(f"PRODUCT_DEFINITION_CONTEXT('part definition',{self.app_ctx},'design')")
        mm = a("(LENGTH_UNIT()NAMED_UNIT(*)SI_UNIT(.MILLI.,.METRE.))")
        rad = a("(NAMED_UNIT(*)PLANE_ANGLE_UNIT()SI_UNIT($,.RADIAN.))")
        sr = a("(NAMED_UNIT(*)SI_UNIT($,.STERADIAN.)SOLID_ANGLE_UNIT())")
        unc = a(f"UNCERTAINTY_MEASURE_WITH_UNIT(LENGTH_MEASURE(1.E-03),{mm},'distance_accuracy_value','confusion accuracy')")
        self.geo_ctx = a("(GEOMETRIC_REPRESENTATION_CONTEXT(3)GLOBAL_UNCERTAINTY_ASSIGNED_CONTEXT((" + unc +
                         "))GLOBAL_UNIT_ASSIGNED_CONTEXT((" + f"{mm},{rad},{sr}" +
                         "))REPRESENTATION_CONTEXT('Context #1','3D Context with UNIT and UNCERTAINTY'))")
        self.origin_pt = a("CARTESIAN_POINT('',(0.,0.,0.))")
        self.dz = a("DIRECTION('',(0.,0.,1.))")
        self.dx = a("DIRECTION('',(1.,0.,0.))")
        self.style_items = []

    def _axis(self):
        return self.add(f"AXIS2_PLACEMENT_3D('',{self.origin_pt},{self.dz},{self.dx})")

    def _product(self, name, pid):
        a = self.add
        p = a(f"PRODUCT({_s(pid)},{_s(name)},'',({self.prod_ctx}))")
        self.products.append(p)
        pdf = a(f"PRODUCT_DEFINITION_FORMATION('','',{p})")
        pd = a(f"PRODUCT_DEFINITION('design','',{pdf},{self.pd_ctx})")
        pds = a(f"PRODUCT_DEFINITION_SHAPE('','',{pd})")
        return pd, pds

    def _color(self, rgb):
        key = tuple(round(c, 4) for c in rgb)
        if key not in self._colors:
            a = self.add
            col = a(f"COLOUR_RGB('',{_f(key[0])},{_f(key[1])},{_f(key[2])})")
            fasc = a(f"FILL_AREA_STYLE_COLOUR('',{col})")
            fas = a(f"FILL_AREA_STYLE('',({fasc}))")
            ssfa = a(f"SURFACE_STYLE_FILL_AREA({fas})")
            sss = a(f"SURFACE_SIDE_STYLE('',({ssfa}))")
            ssu = a(f"SURFACE_STYLE_USAGE(.BOTH.,{sss})")
            self._colors[key] = a(f"PRESENTATION_STYLE_ASSIGNMENT(({ssu}))")
        return self._colors[key]

    # ---------- geometry ----------
    def _brep(self, solid):
        a = self.add
        V = solid.verts * FT
        vp = [a(f"VERTEX_POINT('',{a('CARTESIAN_POINT' + chr(40) + chr(39) + chr(39) + ',(' + ','.join(_f(c) for c in v) + '))')})")
              for v in V]
        edges = {}

        def oriented(i, j):
            if (j, i) in edges:
                return a(f"ORIENTED_EDGE('',*,*,{edges[(j, i)]},.F.)")
            d = V[j] - V[i]
            L = np.linalg.norm(d)
            dirn = a("DIRECTION(''," + "(" + ",".join(_f(c) for c in d / L) + "))")
            vec = a(f"VECTOR('',{dirn},{_f(L)})")
            pt = a("CARTESIAN_POINT('',(" + ",".join(_f(c) for c in V[i]) + "))")
            line = a(f"LINE('',{pt},{vec})")
            ec = a(f"EDGE_CURVE('',{vp[i]},{vp[j]},{line},.T.)")
            edges[(i, j)] = ec
            return a(f"ORIENTED_EDGE('',*,*,{ec},.T.)")

        from polysolid import face_plane
        faces = []
        for face in solid.faces:
            bounds = []
            for k, loop in enumerate(face):
                oes = [oriented(i, j) for i, j in zip(loop, loop[1:] + loop[:1])]
                el = a("EDGE_LOOP('',(" + ",".join(oes) + "))")
                kind = "FACE_OUTER_BOUND" if k == 0 else "FACE_BOUND"
                bounds.append(a(f"{kind}('',{el},.T.)"))
            n, _ = face_plane(V, face[0])
            P0 = V[face[0][0]]
            e = V[face[0][1]] - P0
            e = e - n * np.dot(e, n)
            e /= np.linalg.norm(e)
            loc = a("CARTESIAN_POINT('',(" + ",".join(_f(c) for c in P0) + "))")
            dn = a("DIRECTION('',(" + ",".join(_f(c) for c in n) + "))")
            de = a("DIRECTION('',(" + ",".join(_f(c) for c in e) + "))")
            plane = a(f"PLANE('',{a(f'AXIS2_PLACEMENT_3D({chr(39)}{chr(39)},{loc},{dn},{de})')})")
            faces.append(a("ADVANCED_FACE('',(" + ",".join(bounds) + f"),{plane},.T.)"))
        shell = a("CLOSED_SHELL('',(" + ",".join(faces) + "))")
        brep = a(f"MANIFOLD_SOLID_BREP({_s(solid.name)},{shell})")
        psa = self._color(solid.color)
        self.style_items.append(a(f"STYLED_ITEM('color',({psa}),{brep})"))
        return brep

    # ---------- assembly ----------
    def _node(self, node, path):
        pid = path
        pd, pds = self._product(node.name, pid)
        if node.solid is not None:
            brep = self._brep(node.solid)
            rep = self.add(f"ADVANCED_BREP_SHAPE_REPRESENTATION({_s(node.name)},({self._axis()},{brep}),{self.geo_ctx})")
            self.add(f"SHAPE_DEFINITION_REPRESENTATION({pds},{rep})")
            return pd, rep
        child_info = [self._node(c, f"{path}.{i + 1}") for i, c in enumerate(node.children)]
        own_axis = self._axis()
        place_axes = [self._axis() for _ in child_info]
        rep = self.add(f"SHAPE_REPRESENTATION({_s(node.name)},(" + ",".join([own_axis] + place_axes) + f"),{self.geo_ctx})")
        self.add(f"SHAPE_DEFINITION_REPRESENTATION({pds},{rep})")
        for i, ((cpd, crep), c) in enumerate(zip(child_info, node.children)):
            nauo = self.add(f"NEXT_ASSEMBLY_USAGE_OCCURRENCE({_s(f'{path}.{i + 1}')},{_s(c.name)},'',{pd},{cpd},$)")
            npds = self.add(f"PRODUCT_DEFINITION_SHAPE('','',{nauo})")
            child_axis = self._axis()
            idt = self.add(f"ITEM_DEFINED_TRANSFORMATION('','',{child_axis},{place_axes[i]})")
            rr = self.add(f"(REPRESENTATION_RELATIONSHIP('','',{crep},{rep})"
                          f"REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION({idt})SHAPE_REPRESENTATION_RELATIONSHIP())")
            self.add(f"CONTEXT_DEPENDENT_SHAPE_REPRESENTATION({rr},{npds})")
        return pd, rep

    def write(self, root, filename, description="", author=""):
        self.products = []
        self._context()
        self._node(root, "1")
        self.add("PRODUCT_RELATED_PRODUCT_CATEGORY('part',$,(" + ",".join(self.products) + "))")
        self.add("MECHANICAL_DESIGN_GEOMETRIC_PRESENTATION_REPRESENTATION('',(" +
                 ",".join(self.style_items) + f"),{self.geo_ctx})")
        ts = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        head = ["ISO-10303-21;", "HEADER;",
                f"FILE_DESCRIPTION(({_s(description)}),'2;1');",
                f"FILE_NAME({_s(filename.split('/')[-1])},{_s(ts)},({_s(author)}),(''),'linncove stepwriter','','');",
                "FILE_SCHEMA(('AUTOMOTIVE_DESIGN { 1 0 10303 214 1 1 1 1 }'));", "ENDSEC;", "DATA;"]
        with open(filename, "w") as fh:
            fh.write("\n".join(head + self.lines + ["ENDSEC;", "END-ISO-10303-21;"]) + "\n")
        return self.n
