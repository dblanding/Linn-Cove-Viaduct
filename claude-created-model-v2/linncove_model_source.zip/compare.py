import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from alignment import plan, grade_elev, CURVES
from viaduct import segment_layout, PIERS, ABUT, FOOTING_TOP, pier_solids, H_BOX, OVERLAY
fig,(a1,a2)=plt.subplots(2,1,figsize=(16,11),dpi=100,gridspec_kw=dict(height_ratios=[1.25,1]))
S=np.linspace(27600,29000,1400); P=np.array([plan(s) for s in S])
a1.plot(P[:,0],P[:,1],'k-',lw=0.8)
for side in (1,-1):
    E=np.array([[p[0]+side*18.75*np.sin(p[2]),p[1]-side*18.75*np.cos(p[2])] for p in [plan(s) for s in np.linspace(27676,28923.8,600)]])
    a1.plot(E[:,0],E[:,1],color='saddlebrown',lw=1.2)
for n,s0,s1,pier in segment_layout():
    x,y,t=plan(s0); a1.plot([x-18.75*np.sin(t),x+18.75*np.sin(t)],[y+18.75*np.cos(t),y-18.75*np.cos(t)],color='saddlebrown',lw=0.3)
for i,s in enumerate(PIERS):
    x,y,t=plan(s); a1.plot(x,y,'rs',ms=6); a1.annotate(f"Pier {i+1}\n{int(s//100)}+{s%100:05.2f}",(x,y),xytext=(8,-22),textcoords='offset points',fontsize=8,color='r')
for c in CURVES:
    for k in ("TS","SC","CS","ST"):
        x,y,t=plan(c[k]); a1.plot(x,y,'bo',ms=3); a1.annotate(k,(x,y),xytext=(-12,6),textcoords='offset points',fontsize=7,color='b')
a1.set_aspect('equal'); a1.grid(alpha=.3); a1.set_title("Model plan (ft, X east / Y north from C/L brg Abut 1 = NNE end): edges, segment joints, piers, spiral points"); a1.arrow(-700,-150,0,40,head_width=8,color='k'); a1.text(-706,-102,'N')
# developed elevation
st=np.linspace(27676,28923.8,500); g=np.array([grade_elev(s) for s in st])
a2.fill_between(st,g-OVERLAY-H_BOX,g-OVERLAY,color='tan',ec='saddlebrown')
for n,s0,s1,pier in segment_layout(): a2.plot([s0,s0],[grade_elev(s0)-OVERLAY-H_BOX,grade_elev(s0)-OVERLAY],color='saddlebrown',lw=0.4)
for i,s in enumerate(PIERS):
    cols,f=pier_solids(i); zt=max(c.verts[:,2].max() for c in cols)+4300
    a2.add_patch(plt.Rectangle((s-3,FOOTING_TOP[i]),6,grade_elev(s)-OVERLAY-H_BOX-FOOTING_TOP[i],color='peru'))
    a2.add_patch(plt.Rectangle((s-10,FOOTING_TOP[i]-5),20,5,color='gray'))
    a2.text(s+4,FOOTING_TOP[i]-4,f"Pier {i+1}\nftg {FOOTING_TOP[i]:.1f}",fontsize=8)
a2.set_xlim(27600,29000); a2.set_ylim(4300,4410); a2.grid(alpha=.3)
a2.set_xticks(np.arange(27600,29001,100)); a2.set_xticklabels([f"{int(t//100)}" for t in np.arange(27600,29001,100)])
a2.set_title("Model developed elevation (vertical exaggeration as on sheets 19-21: 2x)"); a2.set_aspect(2*20/10/2*0.5*2)
plt.tight_layout(); plt.savefig("out/model_plan_and_elevation.png")
