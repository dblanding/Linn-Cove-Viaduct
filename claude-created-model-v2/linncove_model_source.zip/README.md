# Linn Cove Viaduct STEP model

Generated from the FHWA contract plan sheets (Project BR2H7, Barrett Daffin & Figg / Europe Etudes,
special consultant Jean M. Muller, 1978): sheets 10, 19, 20, 21, 39, 56, 113, 119.

## Files
- `Linn_Cove_Viaduct.step`: the completed bridge. 153 precast box segments, overlay, parapets, 7 piers
  (stacked precast column segments plus 20 ft dia footings), 2 abutments.
- `Linn_Cove_Erection_Stage.step`: progressive placing in progress, working from the low south end
  (Abutment 2, segment 1) up toward the high NNE end (Abutment 1, segment 153). Segments 1-64 erected,
  Abutment 2 and Piers 7-5 built, Temporary Support 4-5 ahead of the cantilever. The S-20 stiffleg has its
  swing axis over the downhill web of segment 63 and is lowering segment 65.
- `Stiffleg_Derrick_S20.step`: the derrick on its own (boom at 70 deg).

STEP AP214 (AUTOMOTIVE_DESIGN), units mm, nested assembly with part names and colors.
All solids are planar-faced B-reps (MANIFOLD_SOLID_BREP / ADVANCED_FACE on PLANE).

## Coordinate system
X = east, Y = north (NC State Plane grid bearings), origin on the centerline at C/L bearing
Abutment 1 (Sta 276+78.50, the high NNE end). Z = elevation - 4300 ft. For example, Z = 30480 mm is
elevation 4400 ft. Stationing runs south-west, down the 2.44%/1.9% grades. The bearings on the sheets
are written in the stationing direction, and the contours on sheet 10 put the uphill side
(Grandfather Mountain, NW) to the right of the line.

## From the drawings
- Horizontal alignment: three spiral-curve-spiral curves (Rc 249.11 / 249.11 / 358.10 ft; spirals
  200/180, 180/180, 180/200 ft), stations TS/SC/CS/ST as on sheets 19-21. Integrated deflections
  reproduce 65 deg 57', 75 deg 26', 58 deg 35'. The local tangent at Pier 4 matches sheet 39 (S12-14-43W) within 4".
- Profile: -2.44% / -1.9% grades, 500 ft vertical curve, VPI 280+00 at El. 4394.85 (top of overlay at C/L).
- Superelevation: 10% on circular curves, linear through the spirals, rotated about the C/L.
- Segment section (sheet 56): 37'-6" top, 9'-0" deep single cell, 18'-0" bottom flange, 8" top slab,
  11" cantilever tip, 1'-7" at web, 1'-8" R fillet, 12"/16" bottom slab.
- Segment layout: pier segments 5 ft at each pier, numbered 153 (Abut 1) to 1 (Abut 2), with typical-segment
  counts per span taken from the elevations (12-19-21-21-21-21-19-12). Joints are vertical and radial;
  each segment is a ruled solid between its two joint faces.
- Piers: C/L stations, hollow elongated column turned 90 deg to the local tangent, top cut to the
  segment soffit. Footings 20 ft dia x 5 ft. Pier 4 footing top 4329.196 (sheet 39).

## Approximations
- Footing elevations for Piers 1-3 and 5-7 are scaled from the elevation views (checked: Pier 4 scales
  within about 1 ft of its given value).
- The pier column outline is scaled from sheets 39/119. Precast pier pieces are split evenly by count.
- The parapet height (2'-8") is assumed. Abutments are simplified blocks. Pier segments are drawn hollow
  (the real ones have diaphragms). Footings are 36-sided polygons.
- Derrick: only the type (American S-20), 70 ft boom, 125 kips at 25 ft, and its placement are documented
  (PCI Journal 1985). The base layout follows construction photos: swing axis over the downhill web of
  the next-to-last segment, one sill back along the deck, the other cantilevered over the downhill edge,
  so the closed quadrant lies over open air. Mast height (42 ft), sill length (28 ft) and member sizes
  are representative. In the scene the hook radius is 19.8 ft and the boom is at 76 deg.
- The temporary support follows the schematic on sheet 113 (contractor-designed in reality).

## Regenerating
Plain Python 3 + numpy (no CAD kernel needed): `python3 build.py`, then `python3 check_step.py out/*.step`.
The checker re-reads each file and verifies references, closed shells, edge pairing, loop orientation,
planarity and positive volume.
