"""Linn Cove Viaduct superstructure and substructure solids."""
import numpy as np
from alignment import section_frame, plan, grade_elev, Z_DATUM
from polysolid import loft, frame_points, ccw, cw, vertical_prism, circle, Solid

IN = 1 / 12

# ---------------- Typical segment cross-section (sheet 56, Dwg 39) ----------------
# Coordinates (u right, v up) in ft, origin at C/L top of concrete.
H_BOX = 9.0


def _fillet(p_prev, corner, p_next, r, n=4):
    """Replace a corner by a circular arc of radius r (n chords)."""
    a = np.asarray(p_prev, float) - corner; a /= np.linalg.norm(a)
    b = np.asarray(p_next, float) - corner; b /= np.linalg.norm(b)
    half = np.arccos(np.clip(np.dot(a, b), -1, 1)) / 2
    dist = r / np.tan(half)
    t1, t2 = corner + a * dist, corner + b * dist
    bis = (a + b) / np.linalg.norm(a + b)
    ctr = corner + bis * r / np.sin(half)
    a1 = np.arctan2(*(t1 - ctr)[::-1]); a2 = np.arctan2(*(t2 - ctr)[::-1])
    da = (a2 - a1 + np.pi) % (2 * np.pi) - np.pi
    return [ctr + r * np.array([np.cos(a1 + da * k / n), np.sin(a1 + da * k / n)]) for k in range(n + 1)]


def segment_profile():
    # right half of outer boundary, from top C/L going clockwise around the right side
    tip_t = (18.75, 0.0)
    tip_b = (18.75, -11 * IN)          # 11" at cantilever tip
    hch = (14.917, -11 * IN)           # 3'-10" from edge: haunch begins
    web_top = np.array([10.333, -19 * IN])  # 1'-7" at web face
    web_bot = (9.0, -H_BOX)            # bottom flange 18'-0" wide
    arc = _fillet(hch, web_top, web_bot, 20 * IN, n=4)   # 1'-8" R fillet
    right = [tip_t, tip_b, hch] + [tuple(p) for p in arc] + [web_bot]
    left = [(-u, v) for (u, v) in reversed(right)]
    outer = ccw(np.array(right + left))
    # inner void (cell)
    rv = [(5.0, -8 * IN), (8.833, -19 * IN), (7.740, -H_BOX + 16 * IN), (4.917, -H_BOX + 12 * IN)]
    lv = [(-u, v) for (u, v) in reversed(rv)]
    inner = cw(np.array(rv + lv))
    return outer, inner


OVERLAY = 2 * IN
PARAPET_W = 19 * IN       # 1'-7" (37'-6" - 34'-4" roadway)/2
PARAPET_H = 32 * IN       # assumed height above deck (not dimensioned on these sheets)


def placed(profile, s, dv=0.0):
    O, t, u, v = section_frame(s)
    return frame_points(profile, O + v * (dv - OVERLAY), u, v)


# ---------------- Segment layout ----------------
PIERS = [27777.0, 27940.0, 28120.0, 28300.0, 28480.0, 28660.0, 28823.0]
ABUT = [27678.50, 28921.50]
DECK_START, DECK_END = ABUT[0] - 2.5, ABUT[1] + 28 * IN   # 2'-6" / 2'-4" past bearings
PIER_SEG = 5.0
# number of typical segments in each run between pier segments (from sheet elevations)
RUNS = [12, 19, 21, 21, 21, 21, 19, 12]
PIER_SEG_NUMBERS = [141, 121, 99, 77, 55, 33, 13]


def segment_layout():
    """List of (number, s_start, s_end, is_pier_segment); 153 at Abut 1 down to 1."""
    bounds = [DECK_START]
    for p in PIERS:
        bounds += [p - PIER_SEG / 2, p + PIER_SEG / 2]
    bounds.append(DECK_END)
    segs, num = [], 153
    for i, n in enumerate(RUNS):
        a, b = bounds[2 * i], bounds[2 * i + 1]
        for k in range(n):
            segs.append((num, a + (b - a) * k / n, a + (b - a) * (k + 1) / n, False))
            num -= 1
        if i < len(PIERS):
            segs.append((num, bounds[2 * i + 1], bounds[2 * i + 2], True))
            num -= 1
    assert num == 0 and len(segs) == 153, (num, len(segs))
    return segs


CONCRETE = (0.74, 0.66, 0.57)      # iron-oxide tinted
CONCRETE_ALT = (0.69, 0.61, 0.53)
PIER_SEG_COLOR = (0.66, 0.57, 0.49)
ASPHALT = (0.22, 0.22, 0.23)
FOOTING = (0.60, 0.60, 0.58)


def segment_solid(num, s0, s1, is_pier, color=None):
    outer, inner = segment_profile()
    if color is None:
        color = PIER_SEG_COLOR if is_pier else (CONCRETE if num % 2 else CONCRETE_ALT)
    name = f"Segment {num}" + (" (pier segment)" if is_pier else "")
    return loft(name, [[placed(outer, s0), placed(inner, s0)],
                       [placed(outer, s1), placed(inner, s1)]], color)


def strip_solid(name, profile, stations, color):
    return loft(name, [[placed(profile, s)] for s in stations], color)


def overlay_and_parapets(s_from, s_to, stations):
    st = [s for s in stations if s_from <= s <= s_to]
    hw = 18.75 - PARAPET_W
    ov = ccw(np.array([[-hw, 0], [hw, 0], [hw, OVERLAY], [-hw, OVERLAY]]))
    par_r = ccw(np.array([[hw, 0], [18.75, 0], [18.75, PARAPET_H], [hw + 3 * IN, PARAPET_H], [hw, PARAPET_H - 3 * IN]]))
    par_l = ccw(np.array([[-u, v] for u, v in par_r]))
    return [strip_solid("Bituminous overlay (2 in)", ov, st, ASPHALT),
            strip_solid("Parapet, right", par_r, st, CONCRETE),
            strip_solid("Parapet, left", par_l, st, CONCRETE)]


# ---------------- Piers (sheets 39, 119) ----------------
# Plan profile of precast hollow pier column; a = transverse (along pier long axis), b = along tangent.
def pier_profile():
    A, Ac, B, Bc, Bw, dent = 9.15, 4.8, 2.0, 3.37, 2.86, 0.5
    outer = [(A, -B), (A - dent * 0.6, -B / 2), (A - dent, 0), (A - dent * 0.6, B / 2), (A, B),
             (Ac, Bc), (0, Bw), (-Ac, Bc), (-A, B), (-A + dent * 0.6, B / 2), (-A + dent, 0),
             (-A + dent * 0.6, -B / 2), (-A, -B), (-Ac, -Bc), (0, -Bw), (Ac, -Bc)]
    # inner stadium void
    L, r = 7.75, 1.94
    ang = np.linspace(-np.pi / 2, np.pi / 2, 7)
    right = [(L - r + r * np.cos(a), r * np.sin(a)) for a in ang]
    left = [(-L + r - r * np.cos(a), -r * np.sin(a)) for a in ang]
    inner = right + left
    return np.array(outer), np.array(inner)


# top of footing elevations: Pier 4 from sheet 39 (4329.196); others scaled from elevations
FOOTING_TOP = [4357.0, 4347.0, 4318.0, 4329.196, 4334.0, 4351.5, 4349.3]
PIER_PIECES = [5, 5, 8, 7, 6, 3, 3]          # numbered precast pier segments (sheet 119)
FOOTING_D, FOOTING_T = 20.0, 5.0


def soffit_plane(s):
    O, t, u, v = section_frame(s)
    p = O + v * (-OVERLAY - H_BOX)
    return v, float(np.dot(v, p))


def pier_solids(i):
    s = PIERS[i]
    x, y, th = plan(s)
    t = np.array([np.cos(th), np.sin(th), 0.0])
    r = np.array([np.sin(th), -np.cos(th), 0.0])
    ctr = np.array([x, y, 0.0])
    outer, inner = pier_profile()
    z_ft = FOOTING_TOP[i] - Z_DATUM
    n, d = soffit_plane(s)
    z_top_cl = (d - n[0] * x - n[1] * y) / n[2]
    k = PIER_PIECES[i] + 1                      # numbered pieces + top segment
    zs = np.linspace(z_ft, z_top_cl, k + 1)
    solids = []
    for j in range(k):
        top = (n, d) if j == k - 1 else zs[j + 1]
        nm = f"Pier {i + 1} column, " + ("top segment" if j == k - 1 else f"segment {j + 1}")
        col = (0.71, 0.63, 0.55) if j % 2 else (0.67, 0.59, 0.51)
        solids.append(vertical_prism(nm, outer, [inner], zs[j], top, ctr, r, t, col))
    foot = vertical_prism(f"Pier {i + 1} footing (20 ft dia x 5 ft)", circle(FOOTING_D / 2, 36), [],
                          z_ft - FOOTING_T, z_ft, ctr, r, t, FOOTING)
    return solids, foot


# ---------------- Abutments (simplified) ----------------
ABUT_BOTTOM = [4385.0, 4353.0]


def abutment_solids(k):
    s = ABUT[k]
    x, y, th = plan(s)
    t = np.array([np.cos(th), np.sin(th), 0.0])
    r = np.array([np.sin(th), -np.cos(th), 0.0])
    ctr = np.array([x, y, 0.0])
    zb = ABUT_BOTTOM[k] - Z_DATUM
    sgn = -1 if k == 0 else 1                 # direction away from the bridge
    face = 2.833 if k == 0 else 3.0           # Begin/End Bridge (face of backwall) offset from bearing
    seat = np.array([[-19.5, -3.0 * sgn], [19.5, -3.0 * sgn], [19.5, face * sgn], [-19.5, face * sgn]])
    back = np.array([[-19.5, face * sgn], [19.5, face * sgn], [19.5, (face + 3.0) * sgn], [-19.5, (face + 3.0) * sgn]])
    n, d = soffit_plane(s)
    seat_s = vertical_prism(f"Abutment {k + 1} bearing seat", seat, [], zb, (n, d), ctr, r, t, FOOTING)
    O, tt, u, v = section_frame(s + face * sgn)
    z_top = O[2]
    back_s = vertical_prism(f"Abutment {k + 1} backwall", back, [], zb, z_top, ctr, r, t, FOOTING)
    return [seat_s, back_s]
