"""Independent re-read of a STEP file: resolves every reference and rebuilds
each MANIFOLD_SOLID_BREP from its entities, checking topology and geometry."""
import re, sys
import numpy as np

ENT = re.compile(r"^#(\d+)=(.*);$")


def parse(fn):
    ents = {}
    with open(fn) as f:
        txt = f.read()
    assert txt.startswith("ISO-10303-21;") and txt.rstrip().endswith("END-ISO-10303-21;")
    data = txt.split("DATA;", 1)[1].split("ENDSEC;", 1)[0]
    for line in data.strip().split("\n"):
        m = ENT.match(line)
        assert m, line[:80]
        ents[int(m.group(1))] = m.group(2)
    return ents


def args(s):
    """Split top-level args of TYPE(...)."""
    i = s.index("(")
    body = s[i + 1:s.rindex(")")]
    out, depth, cur, q = [], 0, "", False
    for ch in body:
        if ch == "'":
            q = not q
        if not q and ch == "(":
            depth += 1
        if not q and ch == ")":
            depth -= 1
        if not q and ch == "," and depth == 0:
            out.append(cur); cur = ""
        else:
            cur += ch
    out.append(cur)
    return [a.strip() for a in out]


def refs(s):
    return [int(r) for r in re.findall(r"#(\d+)", s)]


def nums(s):
    return np.array([float(x) for x in s.strip("()").split(",")])


def check(fn, render=None):
    E = parse(fn)
    for k, v in E.items():
        for r in refs(v):
            assert r in E, f"#{k} references missing #{r}"
    typ = lambda k: E[k].split("(", 1)[0]
    pt = lambda k: nums(args(E[k])[1])
    breps = [k for k in E if typ(k) == "MANIFOLD_SOLID_BREP"]
    total_vol, tris, worst_dev = 0.0, [], 0.0
    for b in breps:
        shell = refs(args(E[b])[1])[0]
        faces = refs(args(E[shell])[1])
        use = {}
        vol = 0.0
        for fc in faces:
            fa = args(E[fc])
            bounds, plane, sense = refs(fa[1]), refs(fa[2])[0], fa[3]
            assert typ(plane) == "PLANE" and sense == ".T."
            ax = refs(args(E[plane])[1])[0]
            loc, nrm, _ = [r for r in refs(args(E[ax])[1] + "," + args(E[ax])[2] + "," + args(E[ax])[3])]
            P0, n = pt(loc), nums(args(E[nrm])[1])
            for bi, bd in enumerate(bounds):
                loop = refs(args(E[bd])[1])[0]
                oes = refs(args(E[loop])[1])
                verts = []
                for oe in oes:
                    oa = args(E[oe])
                    ec, ori = refs(oa[3])[0], oa[4]
                    ea = args(E[ec])
                    v1, v2 = refs(ea[1])[0], refs(ea[2])[0]
                    if ori == ".F.":
                        v1, v2 = v2, v1
                    key = (ec, ori)
                    assert key not in use, f"edge #{ec} used twice in same sense (brep #{b})"
                    use[key] = True
                    verts.append((v1, v2))
                for (a1, a2), (b1, b2) in zip(verts, verts[1:] + verts[:1]):
                    assert a2 == b1, f"loop #{loop} not continuous"
                P = np.array([pt(refs(args(E[v])[1])[0]) for v, _ in verts])
                worst_dev = max(worst_dev, np.abs((P - P0) @ n).max())
                # orientation: loop normal agrees with plane normal for outer, opposite for holes
                nn = np.zeros(3)
                for i in range(len(P)):
                    nn += np.cross(P[i], P[(i + 1) % len(P)])
                kind = typ(bd)
                assert (np.dot(nn, n) > 0) == (kind == "FACE_OUTER_BOUND"), f"loop orientation #{loop}"
                for i in range(1, len(P) - 1):
                    vol += np.dot(P[0], np.cross(P[i], P[i + 1])) / 6
                    if render is not None and bi == 0:
                        tris.append((P[0], P[i], P[i + 1]))
                if render is not None and bi > 0:
                    pass
        for (ec, ori) in use:
            other = ".F." if ori == ".T." else ".T."
            assert (ec, other) in use, f"edge #{ec} used once only: open shell (brep #{b})"
        assert vol > 0, f"brep #{b} negative volume"
        total_vol += vol
    names = [args(E[k])[1] for k in E if typ(k) == "PRODUCT"]
    nauo = sum(1 for k in E if typ(k) == "NEXT_ASSEMBLY_USAGE_OCCURRENCE")
    styled = sum(1 for k in E if typ(k) == "STYLED_ITEM")
    print(f"{fn}: {len(E)} entities, {len(breps)} closed solids, {len(names)} products, "
          f"{nauo} assembly links, {styled} colored items, max plane deviation {worst_dev:.2e} mm, "
          f"total volume {total_vol / 304.8 ** 3 / 27:.1f} yd3  -> OK")
    return E


if __name__ == "__main__":
    for fn in sys.argv[1:]:
        check(fn)
